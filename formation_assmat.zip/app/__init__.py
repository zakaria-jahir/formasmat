# Ce fichier peut rester vide pour l'instant
# Il indique que le dossier app est un package Python
