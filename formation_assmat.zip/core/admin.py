from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import (
    User, Formation, Session, SessionDate, 
    TrainingRoom, TrainingWish, 
    CompletedTraining, Trainer
)

# Register your models here.

class SessionDateInline(admin.TabularInline):
    model = SessionDate
    extra = 1

@admin.register(Session)
class SessionAdmin(admin.ModelAdmin):
    list_display = ('id', 'formation', 'get_dates', 'get_trainers', 'status', 'iperia_opening_date', 'iperia_deadline')
    list_filter = ('status', 'formation', 'trainers')
    search_fields = ('formation__name', 'trainers__username', 'trainers__last_name')
    inlines = [SessionDateInline]
    filter_horizontal = ('trainers',)

    def get_dates(self, obj):
        return ", ".join([date.date.strftime("%d/%m/%Y") for date in obj.dates.all()])
    get_dates.short_description = "Dates"

    def get_trainers(self, obj):
        return ", ".join([trainer.get_full_name() for trainer in obj.trainers.all()])
    get_trainers.short_description = "Formateurs"

@admin.register(Formation)
class FormationAdmin(admin.ModelAdmin):
    list_display = ('name', 'code_iperia', 'duration')
    search_fields = ('name', 'code_iperia')

@admin.register(TrainingRoom)
class TrainingRoomAdmin(admin.ModelAdmin):
    list_display = ('name', 'address', 'capacity')
    search_fields = ('name', 'address')

@admin.register(Trainer)
class TrainerAdmin(admin.ModelAdmin):
    list_display = ('__str__', 'get_email', 'get_phone')
    search_fields = ('user__first_name', 'user__last_name', 'user__email')
    ordering = ('user__last_name', 'user__first_name')

    def get_email(self, obj):
        return obj.user.email
    get_email.short_description = "Email"

    def get_phone(self, obj):
        return obj.user.phone
    get_phone.short_description = "Téléphone"

class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_staff', 'is_trainer')
    list_filter = ('is_staff', 'is_trainer', 'groups')
    fieldsets = UserAdmin.fieldsets + (
        ('Informations supplémentaires', {'fields': ('is_trainer', 'address', 'phone')}),
    )

admin.site.register(User, CustomUserAdmin)
admin.site.register(TrainingWish)
admin.site.register(CompletedTraining)
