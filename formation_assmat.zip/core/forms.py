from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import get_user_model
from .models import Formation, Trainer, TrainingRoom, TrainingWish, Session, SessionDate

User = get_user_model()

class UserRegistrationForm(UserCreationForm):
    """Formulaire d'inscription utilisateur."""
    class Meta:
        model = User
        fields = ['username', 'email', 'first_name', 'last_name', 'phone', 'address']

class UserProfileForm(forms.ModelForm):
    """Formulaire de profil utilisateur."""
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email', 'phone', 'address', 'rpe_association']
        widgets = {
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'phone': forms.TextInput(attrs={'class': 'form-control'}),
            'address': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'rpe_association': forms.TextInput(attrs={'class': 'form-control'}),
        }

class FormationForm(forms.ModelForm):
    class Meta:
        model = Formation
        fields = ['name', 'code_iperia', 'description', 'duration', 'image', 'program_file', 'type', 
                  'is_presentiel', 'is_distanciel', 'is_asynchrone']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
            'duration': forms.NumberInput(attrs={'class': 'form-control'}),
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'code_iperia': forms.TextInput(attrs={'class': 'form-control'}),
            'type': forms.Select(attrs={'class': 'form-select'}),
        }
        help_texts = {
            'duration': 'Durée de la formation en heures',
            'code_iperia': 'Code unique de la formation',
            'type': 'Type de formation',
            'is_presentiel': 'Formation en présentiel',
            'is_distanciel': 'Formation à distance',
            'is_asynchrone': 'Formation asynchrone',
        }

class TrainingRoomForm(forms.ModelForm):
    class Meta:
        model = TrainingRoom
        fields = ['name', 'address', 'capacity', 'equipment']
        widgets = {
            'equipment': forms.Textarea(attrs={'rows': 4}),
        }

class TrainerForm(forms.ModelForm):
    class Meta:
        model = Trainer
        fields = ['first_name', 'last_name', 'email', 'phone', 'specialties', 'bio', 'photo']
        widgets = {
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'phone': forms.TextInput(attrs={'class': 'form-control'}),
            'specialties': forms.SelectMultiple(attrs={'class': 'form-select', 'multiple': 'multiple'}),
            'bio': forms.Textarea(attrs={'class': 'form-control', 'rows': 4}),
        }
        help_texts = {
            'first_name': 'Prénom du formateur',
            'last_name': 'Nom du formateur',
            'email': 'Email professionnel du formateur',
            'phone': 'Numéro de téléphone (optionnel)',
            'specialties': 'Formations sur lesquelles le formateur intervient',
            'bio': 'Courte biographie du formateur',
            'photo': 'Photo du formateur (optionnelle)'
        }

class TrainingWishForm(forms.ModelForm):
    formation = forms.ModelChoiceField(
        queryset=Formation.objects.filter(is_active=True),  # Filtrer uniquement les formations actives
        label="Formation",
        widget=forms.Select(attrs={'class': 'form-select'}),
        empty_label="Sélectionnez une formation"
    )

    class Meta:
        model = TrainingWish
        fields = ['formation', 'notes']
        widgets = {
            'notes': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }

class SessionDateForm(forms.ModelForm):
    """Formulaire pour les dates de session avec salle optionnelle."""
    location = forms.ModelChoiceField(
        queryset=TrainingRoom.objects.all(), 
        required=False, 
        label="Salle",
        widget=forms.Select(attrs={'class': 'form-select'})
    )

    class Meta:
        model = SessionDate
        fields = ['date', 'location']
        widgets = {
            'date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
        }

class SessionForm(forms.ModelForm):
    """Version minimale du formulaire de session pour la compatibilité."""
    class Meta:
        model = Session
        fields = ['formation', 'status', 'iperia_opening_date', 'iperia_deadline']
        widgets = {
            'formation': forms.Select(attrs={'class': 'form-select'}),
            'status': forms.Select(attrs={'class': 'form-select'}),
            'iperia_opening_date': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'iperia_deadline': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'})
        }

class CustomSessionForm(forms.Form):
    """Formulaire personnalisé pour la création de session."""
    
    # Champs de base de la session
    formation = forms.ModelChoiceField(
        queryset=Formation.objects.filter(is_active=True),  # Filtrer uniquement les formations actives
        label="Formation",
        widget=forms.Select(attrs={'class': 'form-select'})
    )
    
    status = forms.ChoiceField(
        choices=Session.STATUS_CHOICES, 
        label="Statut de la session",
        widget=forms.Select(attrs={'class': 'form-select'}),
        initial='PENDING'
    )
    
    iperia_opening_date = forms.DateField(
        label="Date d'ouverture Ipéria",
        widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
        required=False
    )
    
    iperia_deadline = forms.DateField(
        label="Date limite Ipéria",
        widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
        required=False
    )
    
    # Sélection des formateurs
    trainers = forms.ModelMultipleChoiceField(
        queryset=Trainer.objects.filter(
            first_name__isnull=False, 
            last_name__isnull=False
        ).exclude(first_name='', last_name=''),
        label="Formateurs",
        widget=forms.SelectMultiple(attrs={'class': 'form-select'}),
        required=False
    )
    
    # Champs dynamiques pour les dates et salles
    date_count = forms.IntegerField(
        widget=forms.HiddenInput(), 
        initial=0
    )
    
    def __init__(self, *args, **kwargs):
        print("Initialisation du formulaire de session")
        super().__init__(*args, **kwargs)
        
        # Personnaliser l'affichage des formateurs
        self.fields['trainers'].label_from_instance = lambda obj: f"{obj.first_name} {obj.last_name}"
        
        # Ajouter des champs dynamiques pour les dates et salles
        for i in range(5):  # Permettre jusqu'à 5 dates
            self.fields[f'date_{i}'] = forms.DateField(
                label=f"Date {i+1}",
                widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
                required=False
            )
            
            self.fields[f'room_{i}'] = forms.ModelChoiceField(
                queryset=TrainingRoom.objects.all(),
                label=f"Salle pour la date {i+1}",
                widget=forms.Select(attrs={'class': 'form-select'}),
                required=False
            )
        print("Formulaire de session initialisé avec succès")
    
    def clean(self):
        """Validation personnalisée du formulaire."""
        cleaned_data = super().clean()
        
        # Vérifier la cohérence des dates
        if cleaned_data.get('iperia_opening_date') and cleaned_data.get('iperia_deadline'):
            if cleaned_data['iperia_opening_date'] > cleaned_data['iperia_deadline']:
                raise forms.ValidationError("La date d'ouverture ne peut pas être postérieure à la date limite.")
        
        return cleaned_data
    
    def save(self):
        """Enregistrer la session et ses dates."""
        # Créer la session
        session = Session.objects.create(
            formation=self.cleaned_data['formation'],
            status=self.cleaned_data['status'],
            iperia_opening_date=self.cleaned_data.get('iperia_opening_date'),
            iperia_deadline=self.cleaned_data.get('iperia_deadline')
        )
        
        # Ajouter les formateurs
        if self.cleaned_data.get('trainers'):
            session.trainers.set(self.cleaned_data['trainers'])
        
        # Ajouter les dates de session
        date_count = self.cleaned_data.get('date_count', 0)
        for i in range(date_count):
            date = self.cleaned_data.get(f'date_{i}')
            room = self.cleaned_data.get(f'room_{i}')
            
            if date:
                session_date = SessionDate.objects.create(
                    session=session,
                    date=date,
                    location=room
                )
        
        return session
